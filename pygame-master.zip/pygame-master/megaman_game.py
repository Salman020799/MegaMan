import pygame  # Import pygame library for game development
from sys import exit  # Import exit to close the program
import os  # Import os to handle file paths
import random  # Import random for item drops and randomness
import tile_map  # Import custom tile map data

# -------------------------------
# Game configuration variables
# -------------------------------
TILE_SIZE = 32  # Each tile is 32x32 pixels
ROW_COUNT = 16  # Number of rows in the game grid
COLUMN_COUNT = ROW_COUNT  # Number of columns (square grid)
GAME_WIDTH = TILE_SIZE * COLUMN_COUNT  # Total width of the game screen
GAME_HEIGHT = TILE_SIZE * ROW_COUNT  # Total height of the game screen
GAME_MAP = tile_map.OPTIMIZED_GAME_MAP1  # Load the predefined map

# Player starting position and dimensions
PLAYER_X = GAME_WIDTH/2
PLAYER_Y = GAME_HEIGHT/2
PLAYER_WIDTH = 42
PLAYER_HEIGHT = 48
PLAYER_JUMP_WIDTH = 52
PLAYER_JUMP_HEIGHT = 60
PLAYER_SHOOT_WIDTH = 62  # same height as PLAYER_HEIGHT
PLAYER_JUMP_SHOOT_WIDTH = 58  # same height as PLAYER_JUMP_HEIGHT
PLAYER_WALK_WIDTH = 48
PLAYER_WALK_HEIGHT = 48
PLAYER_WALK_SHOOT_WIDTH = 62
PLAYER_DISTANCE = 5  # Not used directly but could represent distance moved

# Physics variables
GRAVITY = 0.5  # Gravity acceleration per frame
FRICTION = 0.4  # Not currently applied in code (for x-axis movement)
PLAYER_VELOCITY_X = 5  # Horizontal movement speed
PLAYER_VELOCITY_Y = -11  # Initial jump velocity

# Player bullet dimensions and speed
PLAYER_BULLET_WIDTH = 16
PLAYER_BULLET_HEIGHT = 12
PLAYER_BULLET_VELOCITY_X = 8

# Health bar dimensions
HEALTH_WIDTH = 16
HEALTH_HEIGHT = 4

# Enemy: Metall
METALL_WIDTH = 36
METALL_HEIGHT = 30
METALL_BULLET_WIDTH = 12
METALL_BULLET_HEIGHT = METALL_BULLET_WIDTH
METALL_BULLET_VELOCITY_X = 2
METALL_BULLET_VELOCITY_Y = METALL_BULLET_VELOCITY_X

# Enemy: Blader
BLADER_WIDTH = 32
BLADER_HEIGHT = 40
BLADER_VELOCITY_X = 4
BLADER_VELOCITY_Y = 2

# Item dimensions and physics
LIFE_ENERGY_WIDTH = 20
LIFE_ENERGY_HEIGHT = 24
BIG_LIFE_ENERGY_WIDTH = 28
BIG_LIFE_ENERGY_HEIGHT = 32
ITEM_VELOCITY_Y = -11  # Items fly upward initially

# -------------------------------
# Image loading function
# -------------------------------
def load_image(image_name, scale=None):
    """
    Load an image from the 'images' folder.
    If scale is provided, resize the image.
    """
    image = pygame.image.load(os.path.join("images", image_name))
    if scale is not None:
        image = pygame.transform.scale(image, scale)
    return image

# -------------------------------
# Load all game images
# -------------------------------
background_image = load_image("background.png")

# Player images for different actions
player_image_right = load_image("megaman-right.png", (PLAYER_WIDTH, PLAYER_HEIGHT))
player_image_left = load_image("megaman-left.png", (PLAYER_WIDTH, PLAYER_HEIGHT))
player_image_jump_right = load_image("megaman-right-jump.png", (PLAYER_JUMP_WIDTH, PLAYER_JUMP_HEIGHT))
player_image_jump_left = load_image("megaman-left-jump.png", (PLAYER_JUMP_WIDTH, PLAYER_JUMP_HEIGHT))
player_image_shoot_right = load_image("megaman-right-shoot.png", (PLAYER_SHOOT_WIDTH, PLAYER_HEIGHT))
player_image_shoot_left = load_image("megaman-left-shoot.png", (PLAYER_SHOOT_WIDTH, PLAYER_HEIGHT))
player_image_jump_shoot_right = load_image("megaman-right-jump-shoot.png",
                                           (PLAYER_JUMP_SHOOT_WIDTH, PLAYER_JUMP_HEIGHT))
player_image_jump_shoot_left = load_image("megaman-left-jump-shoot.png",
                                           (PLAYER_JUMP_SHOOT_WIDTH, PLAYER_JUMP_HEIGHT))
player_image_bullet = load_image("bullet.png", (PLAYER_BULLET_WIDTH, PLAYER_BULLET_HEIGHT))

# Walking animation frames
player_image_walk_right = [load_image(f"megaman-right-walk{i}.png", 
                                      (PLAYER_WALK_WIDTH, PLAYER_WALK_HEIGHT)) for i in range(4)]
player_image_walk_left = [load_image(f"megaman-left-walk{i}.png", 
                                      (PLAYER_WALK_WIDTH, PLAYER_WALK_HEIGHT)) for i in range(4)]
player_image_walk_shoot_right = [load_image(f"megaman-right-walk-shoot{i}.png", 
                                      (PLAYER_WALK_SHOOT_WIDTH, PLAYER_WALK_HEIGHT)) for i in range(4)]
player_image_walk_shoot_left = [load_image(f"megaman-left-walk-shoot{i}.png", 
                                      (PLAYER_WALK_SHOOT_WIDTH, PLAYER_WALK_HEIGHT)) for i in range(4)]

# Tile images
floor_tile_image = load_image("floor-tile.png", (TILE_SIZE, TILE_SIZE))
wall_tile_image = load_image("wall-tile.png", (TILE_SIZE, TILE_SIZE))
beam_tile_image = load_image("beam-tile.png", (TILE_SIZE, TILE_SIZE))
rock_tile1_image = load_image("rock-tile1.png", (TILE_SIZE, TILE_SIZE))
rock_tile2_image = load_image("rock-tile2.png", (TILE_SIZE, TILE_SIZE))
rock_tile3_image = load_image("rock-tile3.png", (TILE_SIZE, TILE_SIZE))
rock_tile4_image = load_image("rock-tile4.png", (TILE_SIZE, TILE_SIZE))
door_tile_image = load_image("door-tile.png", (TILE_SIZE, TILE_SIZE))
room_tile_image = load_image("room-tile.png", (TILE_SIZE, TILE_SIZE))

# Enemy images
metall_image_right = load_image("metall-right.png", (METALL_WIDTH, METALL_HEIGHT))
metall_image_left = load_image("metall-left.png", (METALL_WIDTH, METALL_HEIGHT))
metall_image_guard_right = load_image("metall-right-guard.png", (METALL_WIDTH, METALL_HEIGHT))
metall_image_guard_left = load_image("metall-left-guard.png", (METALL_WIDTH, METALL_HEIGHT))
metall_image_bullet = load_image("metall-bullet.png", (METALL_BULLET_WIDTH, METALL_BULLET_HEIGHT))
health_image = load_image("health.png", (HEALTH_WIDTH, HEALTH_HEIGHT))
life_energy_image = load_image("life-energy.png", (LIFE_ENERGY_WIDTH, LIFE_ENERGY_HEIGHT))
big_life_energy_image = load_image("big-life-energy.png", (BIG_LIFE_ENERGY_WIDTH, BIG_LIFE_ENERGY_HEIGHT))
score_ball_image = load_image("score-ball.png", (TILE_SIZE/2, TILE_SIZE/2))
spike_image = load_image("spike.png", (TILE_SIZE, TILE_SIZE))
blader_image_right = load_image("blader-right.png", (BLADER_WIDTH, BLADER_HEIGHT))
blader_image_left = load_image("blader-left.png", (BLADER_WIDTH, BLADER_HEIGHT))

# -------------------------------
# Initialize pygame and window
# -------------------------------
pygame.init()
window = pygame.display.set_mode((GAME_WIDTH, GAME_HEIGHT))  # Set window size
pygame.display.set_caption("Group 1 Coding - PyGame")  # Window title
pygame.display.set_icon(player_image_right)  # Set window icon
clock = pygame.time.Clock()  # Clock to control FPS
pygame.font.init()
game_font = pygame.font.Font("./megaman-game-font.otf", 24)  # Custom font
game_over = False  # Game over flag

# -------------------------------
# Custom events for invincibility and shooting cooldown
# -------------------------------
INVINCIBLE_END = pygame.USEREVENT + 0
SHOOTING_END = pygame.USEREVENT + 1
# -------------------------------
# Player class
# -------------------------------
class Player(pygame.Rect):
    # Nested class for Player bullets
    class Bullet(pygame.Rect):
        def __init__(self):
            # Bullet position depends on player's direction
            if player.direction == "left":
                pygame.Rect.__init__(self, player.x, player.y + TILE_SIZE/2,
                                     PLAYER_BULLET_WIDTH, PLAYER_BULLET_HEIGHT)
                self.velocity_x = -PLAYER_BULLET_VELOCITY_X  # Move left
            elif player.direction == "right":
                pygame.Rect.__init__(self, player.x + player.width, player.y + TILE_SIZE/2,
                                     PLAYER_BULLET_WIDTH, PLAYER_BULLET_HEIGHT)
                self.velocity_x = PLAYER_BULLET_VELOCITY_X  # Move right
            self.image = player_image_bullet  # Bullet image
            self.used = False  # Flag to remove bullet when it hits something

    # Initialize player attributes
    def __init__(self):
        pygame.Rect.__init__(self, PLAYER_X, PLAYER_Y, PLAYER_WIDTH, PLAYER_HEIGHT)
        self.image = player_image_right
        self.velocity_x = 0
        self.velocity_y = 0
        self.direction = "right"
        self.jumping = False
        self.invincible = False  # Temporary invincibility after damage
        self.max_health = 28
        self.health = self.max_health
        self.shooting = False
        self.bullets = []  # List of bullets fired
        self.score = 0
        self.walking = False
        self.current_walk_index = 0
        self.last_updated_walk_index = pygame.time.get_ticks()  # For walk animation

    # Update player image depending on state (walk, jump, shoot)
    def update_image(self):
        if self.walking and not self.jumping:
            if self.shooting:
                # Walking while shooting
                if self.direction == "right":
                    self.image = player_image_walk_shoot_right[self.current_walk_index]
                elif self.direction == "left":
                    self.image = player_image_walk_shoot_left[self.current_walk_index]
            else:
                # Walking only
                if self.direction == "right":
                    self.image = player_image_walk_right[self.current_walk_index]
                elif self.direction == "left":
                    self.image = player_image_walk_left[self.current_walk_index]
            self.update_walking_animation()  # Update frame index
        else:
            # Reset walking animation if not walking
            self.current_walk_index = 0
            if self.jumping and self.shooting:
                self.image = player_image_jump_shoot_right if self.direction == "right" else player_image_jump_shoot_left
            elif self.shooting:
                self.image = player_image_shoot_right if self.direction == "right" else player_image_shoot_left
            elif self.jumping:
                self.image = player_image_jump_right if self.direction == "right" else player_image_jump_left
            else:
                self.image = player_image_right if self.direction == "right" else player_image_left

    # Update walking animation frame
    def update_walking_animation(self):
        now = pygame.time.get_ticks()
        if now - self.last_updated_walk_index > 250:  # Change frame every 250ms
            self.last_updated_walk_index = now
            self.current_walk_index = (self.current_walk_index + 1) % len(player_image_walk_right)

    # Activate temporary invincibility
    def set_invincible(self, milliseconds=1000):
        self.invincible = True
        pygame.time.set_timer(INVINCIBLE_END, milliseconds, 1)  # Fire event after specified time

    # Fire bullet
    def set_shooting(self):
        if not self.shooting:
            self.shooting = True
            self.bullets.append(Player.Bullet())  # Add new bullet
            pygame.time.set_timer(SHOOTING_END, 250, 1)  # Shooting cooldown

# -------------------------------
# Metall Enemy class
# -------------------------------
class Metall(pygame.Rect):
    # Nested bullet class
    class Bullet(pygame.Rect):
        def __init__(self, metall, velocity_y):
            # Bullet position depends on enemy direction
            if metall.direction == "left":
                pygame.Rect.__init__(self, metall.x, metall.y + TILE_SIZE/2,
                                     METALL_BULLET_WIDTH, METALL_BULLET_HEIGHT)
                self.velocity_x = -METALL_BULLET_VELOCITY_X
            elif metall.direction == "right":
                pygame.Rect.__init__(self, metall.x + metall.width, metall.y + TILE_SIZE/2,
                                     METALL_BULLET_WIDTH, METALL_BULLET_HEIGHT)
                self.velocity_x = METALL_BULLET_VELOCITY_X
            self.velocity_y = velocity_y  # Vertical bullet speed
            self.image = metall_image_bullet
            self.used = False

    # Initialize enemy
    def __init__(self, x, y):
        pygame.Rect.__init__(self, x, y, METALL_WIDTH, METALL_HEIGHT)
        self.image = metall_image_left
        self.velocity_y = 0
        self.direction = "left"
        self.jumping = False
        self.health = 1
        self.bullets = []
        self.last_fired = pygame.time.get_ticks()
        self.guarding = False  # Whether Metall is in guard mode

    # Update image depending on direction and guarding
    def update_image(self):
        if self.direction == "right":
            self.image = metall_image_guard_right if self.guarding else metall_image_right
        elif self.direction == "left":
            self.image = metall_image_guard_left if self.guarding else metall_image_left

    # Shoot bullets if player is in range
    def set_shooting(self):
        if abs(self.x - player.x) <= TILE_SIZE*4:  # Shooting range
            self.guarding = False
            now = pygame.time.get_ticks()
            if now - self.last_fired > 1000:  # 1 second cooldown
                self.last_fired = now
                self.bullets.append(Metall.Bullet(self, -METALL_BULLET_VELOCITY_Y))
                self.bullets.append(Metall.Bullet(self, 0))
                self.bullets.append(Metall.Bullet(self, METALL_BULLET_VELOCITY_Y))
        else:
            self.guarding = True  # Guard if player is far

# -------------------------------
# Blader Enemy class
# -------------------------------
class Blader(pygame.Rect):
    def __init__(self, x, y):
        pygame.Rect.__init__(self, x, y, BLADER_WIDTH, BLADER_HEIGHT)
        self.image = blader_image_right
        self.direction = "right"
        self.health = 3
        self.velocity_x = BLADER_VELOCITY_X
        self.velocity_y = BLADER_VELOCITY_Y
        self.start_x = x  # For movement limits
        self.start_y = y
        self.max_range_x = TILE_SIZE*4  # Horizontal patrol range
        self.max_range_y = TILE_SIZE  # Vertical patrol range

    def update_image(self):
        self.image = blader_image_right if self.direction == "right" else blader_image_left

# -------------------------------
# Tile class (map objects)
# -------------------------------
class Tile(pygame.Rect):
    def __init__(self, x, y, image):
        pygame.Rect.__init__(self, x, y, TILE_SIZE, TILE_SIZE)
        self.image = image

# -------------------------------
# Item class (health, score)
# -------------------------------
class Item(pygame.Rect):
    def __init__(self, x, y, image):
        pygame.Rect.__init__(self, x, y, image.get_width(), image.get_height())
        self.image = image
        self.jumping = False
        self.velocity_y = ITEM_VELOCITY_Y
        self.used = False  # Flag to remove item after pickup

# -------------------------------
# Helper functions
# -------------------------------
def append_tiles(map_code, tile):
    """
    Determine if tile is background or foreground based on map code
    """
    if map_code < 0:
        background_tiles.append(tile)
    else:
        tiles.append(tile)

def create_map():
    """
    Build the game map using GAME_MAP
    """
    for column in range(len(GAME_MAP[0])):
        for row in range(len(GAME_MAP)):
            map_code = GAME_MAP[row][column]
            x = column * TILE_SIZE
            y = row * TILE_SIZE
            # Map codes determine type of tile/enemy/item
            if map_code == 0:  # empty
                continue
            elif abs(map_code) == 1:
                append_tiles(map_code, Tile(x, y, rock_tile1_image))
            elif abs(map_code) == 2:
                append_tiles(map_code, Tile(x, y, rock_tile2_image))
            elif abs(map_code) == 3:
                append_tiles(map_code, Tile(x, y, rock_tile3_image))
            elif abs(map_code) == 4:
                append_tiles(map_code, Tile(x, y, rock_tile4_image))
            elif abs(map_code) == 5:
                append_tiles(map_code, Tile(x, y, floor_tile_image))
            elif abs(map_code) == 6:
                append_tiles(map_code, Tile(x, y, wall_tile_image))
            elif map_code == 7:
                background_tiles.append(Tile(x, y, beam_tile_image))
            elif map_code == 8:
                spikes.append(Tile(x, y, spike_image))
            elif map_code == 9:
                background_tiles.append(Tile(x, y, door_tile_image))
            elif map_code == 10:
                background_tiles.append(Tile(x, y, room_tile_image))
            elif map_code == 11:
                metalls.append(Metall(x, y))
            elif map_code == 12:
                bladers.append(Blader(x, y))

# -------------------------------
# Game reset function
# -------------------------------
def reset_game():
    """
    Resets all objects and player stats
    """
    global player, metalls, metall_bullets, tiles, background_tiles,\
    items, spikes, bladers, game_over
    player = Player()
    metalls = []
    metall_bullets = []
    tiles = []
    background_tiles = []
    items = []
    spikes = []
    bladers = []
    create_map()
    game_over = False
# -------------------------------
# Collision detection functions
# -------------------------------
def check_tile_collision(character):
    """
    Checks if character collides with any tile.
    Returns the first tile collided or None.
    """
    for tile in tiles:
        if character.colliderect(tile):
            return tile
        elif tile.x - character.x > GAME_WIDTH:  # Optimization: stop if tile too far
            return None
    return None

def check_tile_collision_x(character):
    """
    Horizontal collision resolution: move character outside the tile
    """
    tile = check_tile_collision(character)
    if tile is not None:
        if character.velocity_x < 0:  # Moving left
            character.x = tile.x + tile.width  # Push right
        elif character.velocity_x > 0:  # Moving right
            character.x = tile.x - character.width  # Push left
        character.velocity_x = 0

def check_tile_collision_y(character):
    """
    Vertical collision resolution: move character outside the tile
    """
    tile = check_tile_collision(character)
    if tile is not None:
        if character.velocity_y < 0:  # Moving up
            character.y = tile.y + tile.height  # Push down
        elif character.velocity_y > 0:  # Falling
            character.y = tile.y - character.height  # Land on top
            character.jumping = False  # Stop jump
        character.velocity_y = 0

# -------------------------------
# Drop items from enemies
# -------------------------------
def drop_item(character):
    """
    Randomly spawn items after an enemy is defeated
    """
    random_number = random.randint(1, 100)
    if 0 < random_number <= 20:
        items.append(Item(character.x, character.y, big_life_energy_image))
    elif 20 < random_number <= 50:
        items.append(Item(character.x, character.y, life_energy_image))
    elif 50 < random_number <= 75:
        items.append(Item(character.x, character.y, score_ball_image))

# -------------------------------
# Player movement functions
# -------------------------------
def move_player_x(velocity_x):
    """
    Move player horizontally by moving the map
    """
    move_map_x(velocity_x)  # Move all objects opposite to simulate player movement
    tile = check_tile_collision(player)
    if tile is not None:
        move_map_x(-velocity_x)  # Undo movement if collision

def move_map_x(velocity_x):
    """
    Move all map elements (tiles, enemies, bullets, items) horizontally
    """
    for tile in background_tiles:
        tile.x += velocity_x
    for tile in tiles:
        tile.x += velocity_x
    for metall in metalls:
        metall.x += velocity_x
        for bullet in metall.bullets:
            bullet.x += velocity_x
    for bullet in metall_bullets:
        bullet.x += velocity_x
    for item in items:
        item.x += velocity_x
    for spike in spikes:
        spike.x += velocity_x
    for blader in bladers:
        blader.start_x += velocity_x
        blader.x += velocity_x

# -------------------------------
# Game logic update
# -------------------------------
def move():
    """
    Main movement and collision logic for player, enemies, bullets, and items
    """
    global metalls, items, bladers, metall_bullets, game_over

    # Gravity applied to player
    player.velocity_y += GRAVITY
    player.y += player.velocity_y
    check_tile_collision_y(player)  # Stop player on tiles

    # Check collision with spikes
    for spike in spikes:
        if player.colliderect(spike):
            player.health = 0  # Instant death

    # Update player's bullets
    for bullet in player.bullets:
        bullet.x += bullet.velocity_x
        # Check collision with Metall enemies
        for metall in metalls:
            if metall.health > 0 and not bullet.used and bullet.colliderect(metall):
                bullet.used = True
                if not metall.guarding:
                    metall.health -= 1
                    if metall.health <= 0:
                        drop_item(metall)
                        metall_bullets.extend(metall.bullets)
                        player.score += 500
        # Check collision with Blader enemies
        for blader in bladers:
            if blader.health > 0 and not bullet.used and bullet.colliderect(blader):
                bullet.used = True
                blader.health -= 1
                if blader.health <= 0:
                    drop_item(blader)
                    player.score += 500

    # Remove used or off-screen bullets
    player.bullets = [b for b in player.bullets if not b.used and 0 < b.x < GAME_WIDTH]
    metalls = [m for m in metalls if m.health > 0]
    bladers = [b for b in bladers if b.health > 0]

    # Enemy movement and bullets
    for metall in metalls:
        metall.velocity_y += GRAVITY
        metall.y += metall.velocity_y
        check_tile_collision_y(metall)

        # Enemy collision with player
        if not player.invincible and player.colliderect(metall):
            player.health -= 1
            player.set_invincible()

        # Enemy shooting
        metall.set_shooting()
        for bullet in metall.bullets:
            bullet.x += bullet.velocity_x
            bullet.y += bullet.velocity_y
            if not player.invincible and player.colliderect(bullet):
                player.health -= 2
                bullet.used = True
                player.set_invincible()
        metall.bullets = [b for b in metall.bullets if not b.used and 0 < b.x < GAME_WIDTH]

    # Remaining bullets from destroyed Metalls
    for bullet in metall_bullets:
        bullet.x += bullet.velocity_x
        bullet.y += bullet.velocity_y
        if not player.invincible and player.colliderect(bullet):
            player.health -= 2
            bullet.used = True
            player.set_invincible()
    metall_bullets = [b for b in metall_bullets if not b.used and 0 < b.x < GAME_WIDTH]

    # Blader enemy patrol logic
    for blader in bladers:
        # Horizontal patrol
        if abs(blader.x + blader.velocity_x - blader.start_x) >= blader.max_range_x:
            blader.velocity_x *= -1
            blader.direction = "left" if blader.velocity_x < 0 else "right"
        else:
            blader.x += blader.velocity_x
        # Vertical patrol
        if abs(blader.y + blader.velocity_y - blader.start_y) >= blader.max_range_y:
            blader.velocity_y *= -1
        else:
            blader.y += blader.velocity_y
        # Collision with player
        if not player.invincible and player.colliderect(blader):
            player.health -= 1
            player.set_invincible()

    # Item gravity and collection
    for item in items:
        item.velocity_y += GRAVITY
        item.y += item.velocity_y
        check_tile_collision_y(item)
        if player.colliderect(item):
            item.used = True
            if item.image == life_energy_image:
                player.health = min(player.health + 2, player.max_health)
            elif item.image == big_life_energy_image:
                player.health = min(player.health + 8, player.max_health)
            elif item.image == score_ball_image:
                player.score += 1000
    items = [i for i in items if not i.used]

    # Check if game over
    if player.health <= 0 or player.y > GAME_HEIGHT:
        game_over = True

# -------------------------------
# Drawing function
# -------------------------------
def draw():
    """
    Draw all game elements on the screen
    """
    window.fill((20, 18, 167))  # Background color
    window.blit(background_image, (0, 80))  # Background image

    # Draw background tiles
    for tile in background_tiles:
        if tile.x > GAME_WIDTH:
            break
        window.blit(tile.image, tile)

    # Draw map tiles
    for tile in tiles:
        if tile.x > GAME_WIDTH:
            break
        window.blit(tile.image, tile)

    # Draw spikes
    for spike in spikes:
        if spike.x > GAME_WIDTH:
            break
        window.blit(spike.image, spike)

    # Draw player
    player.update_image()
    window.blit(player.image, player)

    # Draw player's bullets
    for bullet in player.bullets:
        window.blit(bullet.image, bullet)

    # Draw Metall enemies and bullets
    for metall in metalls:
        if metall.x <= GAME_WIDTH:
            metall.update_image()
            window.blit(metall.image, metall)
        for bullet in metall.bullets:
            window.blit(bullet.image, bullet)
    # Draw bullets from destroyed Metall
    for bullet in metall_bullets:
        window.blit(bullet.image, bullet)

    # Draw Blader enemies
    for blader in bladers:
        if blader.x > GAME_WIDTH:
            break
        blader.update_image()
        window.blit(blader.image, blader)

    # Draw items
    for item in items:
        if item.x > GAME_WIDTH:
            break
        window.blit(item.image, item)

    # Draw player health bar
    pygame.draw.rect(window, "black", (TILE_SIZE, TILE_SIZE, HEALTH_WIDTH, HEALTH_HEIGHT * player.max_health))
    for i in range(player.max_health - player.health, player.max_health):
        window.blit(health_image, (TILE_SIZE, TILE_SIZE + i*HEALTH_HEIGHT, HEALTH_WIDTH, HEALTH_HEIGHT))

    # Draw score
    text_score = str(player.score).zfill(7)  # Pad with zeros
    text_surface = game_font.render(text_score, False, "white")
    window.blit(text_surface, (GAME_WIDTH/2, TILE_SIZE/2))

    # Draw Game Over text
    if game_over:
        text_surface = game_font.render("Game Over:", False, "white")
        window.blit(text_surface, (GAME_WIDTH/8, GAME_HEIGHT/2))
        text_surface = game_font.render("Press [Enter] to Restart", False, "white")
        window.blit(text_surface, (GAME_WIDTH/8, GAME_HEIGHT/2 + TILE_SIZE))

# -------------------------------
# Initialize game objects
# -------------------------------
player = Player()        # Create the player object
metalls = []             # List to store Metall enemies
metall_bullets = []      # Bullets left from destroyed Metalls
tiles = []               # Map tiles for collision
background_tiles = []    # Background tiles for visuals
items = []               # Collectible items
spikes = []              # Hazardous spike tiles
bladers = []             # Blader enemies
create_map()             # Generate the game map based on GAME_MAP

# -------------------------------
# Main game loop
# -------------------------------
while True:
    for event in pygame.event.get():  # Event handling
        if event.type == pygame.QUIT:  # Quit game
            pygame.quit()
            exit()
        
        if event.type == INVINCIBLE_END:  # End of invincibility
            player.invincible = False
        elif event.type == SHOOTING_END:  # End of shooting animation
            player.shooting = False

    keys = pygame.key.get_pressed()  # Keyboard input

    # Restart game if Enter is pressed after game over
    if (keys[pygame.K_RETURN] or keys[pygame.K_KP_ENTER]) and game_over:
        reset_game()

    # Player jump
    if (keys[pygame.K_UP] or keys[pygame.K_w]) and not player.jumping:
        player.velocity_y = PLAYER_VELOCITY_Y
        player.jumping = True

    # Walking detection
    if keys[pygame.K_LEFT] or keys[pygame.K_a] or keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        player.walking = True
    else:
        player.walking = False

    # Move player left
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        move_player_x(PLAYER_VELOCITY_X)  # Move map to simulate player movement
        player.direction = "left"

    # Move player right
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        move_player_x(-PLAYER_VELOCITY_X)  # Move map to simulate player movement
        player.direction = "right"

    # Shooting
    if keys[pygame.K_x] or keys[pygame.K_SPACE]:
        player.set_shooting()

    # Update game objects and draw
    if not game_over:
        move()   # Update game logic (movement, collisions, bullets)
        draw()   # Draw everything on the screen
        pygame.display.update()
        clock.tick(60)  # Maintain 60 frames per second

