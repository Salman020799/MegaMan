import tkinter as tk  # Tkinter is Python's standard GUI library
from tkinter import messagebox  # For popup dialogs like info, error messages
from PIL import Image, ImageTk  # To handle and display images in Tkinter

# ---------- GLOBAL SETTINGS ----------
WINDOW_WIDTH = 800       # Width of all application windows
WINDOW_HEIGHT = 600      # Height of all application windows
BG_COLOR = "#1e1e2f"     # Default background color (not used if image is present)
ACCENT_COLOR = "#00b894"  # Highlight color for labels/buttons
BUTTON_COLOR = "#0984e3"  # Default color for buttons
BUTTON_HOVER = "#74b9ff"  # Button hover color

# ---------- HELPER FUNCTION ----------
def center_window(win, width, height):
    """
    Centers the given window on the user's screen.
    Calculates X, Y coordinates to place the window in the center.
    """
    screen_width = win.winfo_screenwidth()
    screen_height = win.winfo_screenheight()
    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)
    win.geometry(f"{width}x{height}+{x}+{y}")  # Set window size and position

# ---------- CUSTOM ENTRY WITH PLACEHOLDER ----------
class PlaceholderEntry(tk.Entry):
    """
    A Tkinter Entry widget that supports placeholder text.
    Placeholder disappears when user clicks on the entry and reappears if left empty.
    Supports password hiding automatically.
    """
    def __init__(self, master=None, placeholder="PLACEHOLDER", color="grey", **kwargs):
        super().__init__(master, **kwargs)
        self.placeholder = placeholder  # Placeholder text
        self.placeholder_color = color  # Placeholder text color
        self.default_fg_color = self["fg"]  # Normal text color

        # Bind focus events to clear or add placeholder
        self.bind("<FocusIn>", self._clear_placeholder)
        self.bind("<FocusOut>", self._add_placeholder)

        self._add_placeholder()  # Initialize with placeholder

    def _clear_placeholder(self, event=None):
        """
        Clears placeholder text when user focuses on the entry.
        Shows password as '*' if the placeholder is 'password'.
        """
        if self["fg"] == self.placeholder_color:
            self.delete(0, "end")  # Remove placeholder text
            self["fg"] = self.default_fg_color  # Restore normal color
            if self.placeholder.lower() == "password":
                self.config(show="*")  # Hide password characters

    def _add_placeholder(self, event=None):
        """
        Adds placeholder text if the entry is empty.
        Placeholder text is always visible in plain text.
        """
        if not self.get():
            self.insert(0, self.placeholder)
            self["fg"] = self.placeholder_color
            self.config(show="")  # Show placeholder normally

# ---------- IN-MEMORY USER DATABASE ----------
user_database = {"admin": "admin123"}  
# Simple dictionary storing username: password pairs
# Default account for testing: username=admin, password=admin123

# ---------- LOGIN / SIGNUP WINDOW ----------
class LoginSignupApp:
    """
    Main login window class.
    Provides username/password input, login button, and link to sign-up window.
    """
    def __init__(self, root):
        self.root = root
        self.root.title("Login / Signup")
        center_window(self.root, WINDOW_WIDTH, WINDOW_HEIGHT)  # Center window

        # --- BACKGROUND IMAGE ---
        bg_image = Image.open("megaman_bg.jpg")  # Load background image
        bg_image = bg_image.resize((WINDOW_WIDTH, WINDOW_HEIGHT))  # Resize to fit window
        self.bg_photo = ImageTk.PhotoImage(bg_image)  # Convert to Tkinter-compatible image
        bg_label = tk.Label(self.root, image=self.bg_photo)
        bg_label.place(x=0, y=0, relwidth=1, relheight=1)  # Full window coverage

        # --- CARD FRAME (LOGIN FORM) ---
        self.card = tk.Frame(self.root, bg="#2d3436", bd=5, relief="flat")
        self.card.place(x=20, y=20, width=400, height=350)  # Top-left corner

        # Title label
        self.title = tk.Label(self.card, text="🔑 Login", font=("Arial", 22, "bold"),
                              fg="white", bg="#2d3436")
        self.title.pack(pady=20)

        # Username and password entries with placeholder
        self.username_entry = PlaceholderEntry(self.card, placeholder="Username",
                                               font=("Arial", 14), fg="white", bg="#636e72", relief="flat")
        self.username_entry.pack(pady=10, ipady=5, ipadx=10)

        self.password_entry = PlaceholderEntry(self.card, placeholder="Password",
                                               font=("Arial", 14), fg="white", bg="#636e72", relief="flat")
        self.password_entry.pack(pady=10, ipady=5, ipadx=10)

        # Login button
        self.login_btn = self._create_button(self.card, "Login", self.login)
        self.login_btn.pack(pady=15)

        # Switch to signup button (styled as a link)
        self.switch_btn = tk.Button(self.card, text="Create an account", font=("Arial", 12),
                                    bg="#2d3436", fg=ACCENT_COLOR, bd=0, cursor="hand2",
                                    command=self.show_signup, activeforeground="white", activebackground="#2d3436")
        self.switch_btn.pack()

    # --- BUTTON CREATION HELPER ---
    def _create_button(self, parent, text, command):
        """
        Helper function to create a styled button.
        parent: parent widget (frame)
        text: button label
        command: function to call on click
        """
        btn = tk.Button(parent, text=text, font=("Arial", 14, "bold"),
                        bg=BUTTON_COLOR, fg="white", activebackground=BUTTON_HOVER,
                        activeforeground="black", relief="flat", cursor="hand2",
                        command=command, width=20, height=2)
        return btn

    # --- LOGIN LOGIC ---
    def login(self):
        """
        Handles login verification.
        Checks input username and password against user_database.
        Opens main menu if successful, shows error if not.
        """
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        if username in user_database and user_database[username] == password:
            messagebox.showinfo("Login", "Login Successful!")
            self.root.destroy()  # Close login window
            MainMenu(username)   # Open main menu
        else:
            messagebox.showerror("Error", "Invalid username or password!")

    # --- SHOW SIGNUP WINDOW ---
    def show_signup(self):
        """
        Opens the SignUp window.
        """
        SignupWindow(self.root)

# ---------- SIGNUP WINDOW ----------
class SignupWindow:
    """
    Sign-up window class.
    Allows users to create new accounts.
    """
    def __init__(self, root):
        self.top = tk.Toplevel(root)  # Create a new window on top of login
        self.top.title("Sign Up")
        center_window(self.top, WINDOW_WIDTH, WINDOW_HEIGHT)

        # Background image
        bg_image = Image.open("megaman_bg.jpg")
        bg_image = bg_image.resize((WINDOW_WIDTH, WINDOW_HEIGHT))
        self.bg_photo = ImageTk.PhotoImage(bg_image)
        bg_label = tk.Label(self.top, image=self.bg_photo)
        bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Card frame for sign-up form
        self.card = tk.Frame(self.top, bg="#2d3436", bd=5, relief="flat")
        self.card.place(x=20, y=20, width=400, height=300)

        # Title label
        self.title = tk.Label(self.card, text="📝 Sign Up", font=("Arial", 22, "bold"),
                              fg="white", bg="#2d3436")
        self.title.pack(pady=20)

        # Entry fields
        self.username_entry = PlaceholderEntry(self.card, placeholder="Username",
                                               font=("Arial", 14), fg="white", bg="#636e72", relief="flat")
        self.username_entry.pack(pady=10, ipady=5, ipadx=10)

        self.password_entry = PlaceholderEntry(self.card, placeholder="Password",
                                               font=("Arial", 14), fg="white", bg="#636e72", relief="flat")
        self.password_entry.pack(pady=10, ipady=5, ipadx=10)

        # Sign-up button
        self.signup_btn = tk.Button(self.card, text="Sign Up", font=("Arial", 14, "bold"),
                                    bg=ACCENT_COLOR, fg="white", relief="flat", cursor="hand2",
                                    command=self.signup, width=20, height=2)
        self.signup_btn.pack(pady=15)

    # --- SIGNUP LOGIC ---
    def signup(self):
        """
        Validates and creates a new user.
        Checks for empty fields and duplicate usernames.
        Adds user to in-memory database if valid.
        """
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        if not username or not password or username == "Username" or password == "Password":
            messagebox.showerror("Error", "Please fill all fields")
        elif username in user_database:
            messagebox.showerror("Error", "Username already exists!")
        else:
            user_database[username] = password
            messagebox.showinfo("Success", "Account created! You can login now.")
            self.top.destroy()  # Close sign-up window

# ---------- MAIN MENU WINDOW ----------
class MainMenu:
    """
    Main menu window class.
    Displays welcome message and buttons to start the game or exit.
    """
    def __init__(self, username):
        self.root = tk.Tk()
        self.root.title("Main Menu")
        center_window(self.root, WINDOW_WIDTH, WINDOW_HEIGHT)

        # Background image
        bg_image = Image.open("megaman_bg.jpg")
        bg_image = bg_image.resize((WINDOW_WIDTH, WINDOW_HEIGHT))
        self.bg_photo = ImageTk.PhotoImage(bg_image)
        bg_label = tk.Label(self.root, image=self.bg_photo)
        bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Card frame for main menu buttons
        self.card = tk.Frame(self.root, bg="#2d3436", bd=5, relief="flat")
        self.card.place(x=20, y=20, width=450, height=400)

        # Welcome label (inside card)
        tk.Label(self.card, text=f"🎮 Welcome {username}", font=("Arial", 20, "bold"),
                 fg=ACCENT_COLOR, bg="#2d3436").pack(pady=30)

        # Start Game button
        self.start_btn = self._create_button(self.card, "▶ Start Game", self.start_game)
        self.start_btn.pack(pady=20)

        # Exit button
        self.exit_btn = self._create_button(self.card, "❌ Exit", self.root.destroy)
        self.exit_btn.pack(pady=20)

        self.root.mainloop()  # Keep main menu window running

    # --- BUTTON CREATION HELPER ---
    def _create_button(self, parent, text, command):
        """
        Helper function to create styled buttons in the main menu.
        """
        btn = tk.Button(parent, text=text, font=("Arial", 16, "bold"),
                        bg=BUTTON_COLOR, fg="white", activebackground=BUTTON_HOVER,
                        activeforeground="black", relief="flat", cursor="hand2",
                        command=command, width=20, height=2)
        return btn

    # --- START GAME FUNCTION ---
    def start_game(self):
        """
        Starts the actual game.
        Closes main menu and imports the game module.
        """
        self.root.destroy()  # Close main menu window
        import megaman_game  # Launch your Megaman game module

# ---------- MAIN EXECUTION ----------
if __name__ == "__main__":
    root = tk.Tk()                # Create the root window
    app = LoginSignupApp(root)     # Initialize the login/signup app
    root.mainloop()                # Run the GUI main loop

